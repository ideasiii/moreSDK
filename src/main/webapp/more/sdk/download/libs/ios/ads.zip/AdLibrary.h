//
//  AdLibrary.h
//  AdLibrary
//
//  Created by HsuanLee on 2016/1/28.
//  Copyright © 2016年 lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CoreLocation/CoreLocation.h"

@import GoogleMobileAds;

typedef enum {
    UNKNOWN = 0,
    MALE = 1,
    FEMALE = 2
} Sex;

typedef enum {
    BANNER,
    LARGE_BANNER,
    MEDIUM_RECTANGLE,
    FULL_BANNER,
    LEADERBOARD,
    SMART_BANNER
} AdSize;

@interface AdLibrary : NSObject<GADInterstitialDelegate,GADBannerViewDelegate>

#pragma mark - 插頁廣告
/**
 *  Ad Banner 開始註冊view
 *
 *  @param adID   ad id (@"ca-app-pub-4832528448534343/6994259913")
 */
-(void)createAdBanner:(NSString *)adID;

/**
 *  Ad Banner 開始註冊view
 *
 *  @param adID   ad id (@"ca-app-pub-4832528448534343/6994259913")
 *  @param AdSize AdBannerSize
 */
-(void)createAdBanner:(NSString *)adID AdSize:(AdSize)adSize;

/**
 *  Ad Banner 開始註冊view
 *
 *  @param adID   ad id (@"ca-app-pub-4832528448534343/6994259913")
 *  @param width  使用者自訂廣告寬度
 *  @param height 使用者自訂廣告高度
 */
-(void)createAdBanner:(NSString *)adID width:(NSInteger)width height:(NSInteger)height;
/**
 *  載入廣告並開始顯示廣告
 *
 *  @param rootVC 來源viewController
 */
-(void)adStart:(UIViewController *)rootVC;

#pragma mark - 插頁廣告
/**
 *  Ad Interstitial 開始註冊view
 *
 *  @param adID ad id (@"ca-app-pub-4832528448534343/1555855115")
 */
- (void)createADInterstitial:(NSString*)adID;
/**
 *  顯示跨頁廣告，回傳值代表此廣告是否有彈跳出。
 *
 *  @param rootVC 來源viewController
 */
-(BOOL)interstitialAdShow:(UIViewController*)rootVC;

#pragma mark - 鎖定人群之廣告要求
/**
 *  設定測試裝置
 *
 *  @param phoneID 行動裝置ID
 */
-(void)setTestDevice:(NSString *)phoneID;

/**
 *  設定使用者生日，以西元年月日做為標準，日期會經過檢查，存在不合法月日會回傳false
 *
 *  @param year 使用者生日年份(西元年)
 *  @param month 使用者生日月份(西元年)
 *  @param dayOfMonth 使用者生日日期(西元年)
 */
-(BOOL)setUserBirthday:(NSInteger)year Month:(NSInteger)month dayOfMonth:(NSInteger)dayOfMonth;

/** 鎖定人群之廣告要求
 *  設定使用者性別決定廣告內容
 *
 *  @param gender 0 : UnKnown、1: Male、2: Female
 */
-(void)setUserGender:(Sex)gender;

/** 鎖定人群之廣告要求
 *  設定將廣告設定為兒童專屬
 *
 *  @param isChild true/false
 */
-(void)setForChildDirectedTreatment:(BOOL)isChild;

///** 鎖定人群之廣告要求
// *  設定代表廣告請求的平台來源
// *
// *  @param Agent 平台來源 -- ios 貌似沒有
// */
//-(void)setAgent:(NSString *)agent;

/** 鎖定人群之廣告要求
 *  設定內容網址
 *
 *  @param contentURL 內容網址
 */
-(void)setContentURL:(NSString *)contentURL;

/** 鎖定人群之廣告要求
 *  設定設定廣告地點
 *
 *  @param location 廣告地點
 */
-(void)setLocation:(CLLocation *)location;

/**
 *  實體化
 */
+ (instancetype)sharedManager;

@end
